# Water-Distribution-System 💧🌐
This project optimizes water distribution using map APIs to gather data on water bodies, industries, and houses. Prim's algorithm constructs a cycle-free network, and DFS explores paths. A priority queue identifies the optimal route in blue, emphasizing efficient water distribution.
